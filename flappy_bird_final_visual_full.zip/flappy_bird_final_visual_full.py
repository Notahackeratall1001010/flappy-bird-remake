import pygame
import random
import sys
import time

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((400, 600))
clock = pygame.time.Clock()
pygame.display.set_caption("Flappy Bird - Enhanced")

# Colors
SKY = (135, 206, 235)
PIPE_GREEN = (40, 180, 40)
PIPE_DARK = (20, 120, 20)
PIPE_LIGHT = (70, 220, 70)
PIPE_HIGHLIGHT = (110, 250, 110)
WING_COLOR = (255, 255, 255)
TAIL_COLOR = (200, 0, 0)
BELLY_COLOR = (255, 100, 100)
TREE_TRUNK = (101, 67, 33)
TREE_LEAF = (34, 139, 34)
GROUND = (222, 184, 135)
RED = (255, 50, 50)
BEAK_ORANGE = (255, 165, 0)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GOLD = (255, 215, 0)
GOLD_LIGHT = (255, 245, 100)
SHADOW = (50, 50, 50)
PUFF_COLOR = (255, 255, 255, 50)
BLUE = (100, 100, 255)

# Constants
FPS = 60
GRAVITY = 0.5
FLAP_STRENGTH = -10
PIPE_SPEED = 3
PIPE_GAP = 150
PIPE_WIDTH = 60
PIPE_CAP_HEIGHT = 20

font = pygame.font.SysFont("Arial", 36)
small_font = pygame.font.SysFont("Arial", 20)

# Global to track coins
global_coin_count = 0
selected_skin = 0
available_skins = ["default", "red", "blue", "wizard"]
chosen_skin = "default"

def pause_menu():
    overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 0))
    screen.blit(overlay, (0, 0))
    pause_text = font.render("Paused", True, WHITE)
    screen.blit(pause_text, (screen.get_width() // 2 - pause_text.get_width() // 2, 250))
    pygame.display.update()
    paused = True
    while paused:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                paused = False
        clock.tick(10)
    for i in range(3, 0, -1):
        screen.fill(SKY)
        countdown_text = font.render(f"{i}", True, WHITE)
        screen.blit(countdown_text, (screen.get_width() // 2 - countdown_text.get_width() // 2, 250))
        pygame.display.update()
        pygame.time.delay(1000)

def game_over_screen(score, coins_collected):
    global global_coin_count
    global_coin_count += coins_collected
    overlay = pygame.Surface(screen.get_size(), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 180))
    screen.blit(overlay, (0, 0))
    over_text = font.render("Game Over", True, WHITE)
    score_text = small_font.render(f"Score: {score}", True, WHITE)
    coin_text = small_font.render(f"Coins Saved: {global_coin_count}", True, GOLD)
    screen.blit(over_text, (screen.get_width() // 2 - over_text.get_width() // 2, 200))
    screen.blit(score_text, (screen.get_width() // 2 - score_text.get_width() // 2, 260))
    screen.blit(coin_text, (screen.get_width() // 2 - coin_text.get_width() // 2, 300))
    pygame.display.update()
    pygame.time.delay(2000)

class Bird:
    def __init__(self, skin="default"):
        self.x = 80
        self.y = 300
        self.vel = 0
        self.skin = skin
        self.flap_timer = 0
        self.trail = []  # Trail positions

    def flap(self):
        self.vel = FLAP_STRENGTH
        self.flap_timer = 5

    def update(self):
        self.vel += GRAVITY
        self.y += self.vel

        if self.skin == "wizard":
            self.trail.append((self.x + 20, self.y + 20))
            if len(self.trail) > 15:
                self.trail.pop(0)

        if self.flap_timer > 0:
            self.flap_timer -= 1

    def draw(self):
        tilt = min(max(self.vel * -3, -30), 30)
        surface = pygame.Surface((50, 35), pygame.SRCALPHA)
        if self.skin == "wizard":
            body_color = (160, 32, 240)  # Purple
            pygame.draw.polygon(surface, (160, 32, 240), [(20, 0), (30, -10), (40, 0)])  # Wizard hat
        elif self.skin == "blue":
            body_color = BLUE
        elif self.skin == "red":
            body_color = RED
        else:
            body_color = BELLY_COLOR
        pygame.draw.ellipse(surface, body_color, (5, 10, 30, 20))
        pygame.draw.polygon(surface, TAIL_COLOR, [(5, 20), (0, 25), (5, 30)])
        pygame.draw.circle(surface, WHITE, (30, 15), 8)
        pygame.draw.circle(surface, BLACK, (32, 15), 3)
        pygame.draw.polygon(surface, BEAK_ORANGE, [(38, 17), (44, 15), (38, 13)])
        pygame.draw.polygon(surface, WING_COLOR, [(10, 20), (15, 10), (20, 20)])
        # Flap puff effect
        if self.flap_timer > 0:
            puff1 = pygame.Surface((8, 8), pygame.SRCALPHA)
            puff2 = pygame.Surface((6, 6), pygame.SRCALPHA)
            pygame.draw.circle(puff1, PUFF_COLOR, (4, 4), 4)
            pygame.draw.circle(puff2, (255, 255, 255, 30), (3, 3), 3)
            screen.blit(puff1, (self.x - 8, self.y + 10))
            screen.blit(puff2, (self.x - 4, self.y + 14))
        
        # Draw trail for wizard
        if self.skin == "wizard":
            for i, (tx, ty) in enumerate(self.trail):
                alpha = max(50, 200 - i * 10)
                lightning = pygame.Surface((6, 6), pygame.SRCALPHA)
                pygame.draw.circle(lightning, (255, 255, 0, alpha), (3, 3), 3)
                screen.blit(lightning, (tx, ty))

        rotated = pygame.transform.rotate(surface, tilt)
        screen.blit(rotated, (self.x, self.y))

    def get_rect(self):
        return pygame.Rect(self.x, self.y, 34, 24)

class Coin:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.collected = False
        self.spin_frame = 0

    def update(self):
        self.spin_frame = (self.spin_frame + 1) % 20

    def draw(self):
        if not self.collected:
            size = 10 + 6 * abs(10 - self.spin_frame) / 10
            pygame.draw.circle(screen, GOLD, (int(self.x), int(self.y)), int(size))
            pygame.draw.circle(screen, GOLD_LIGHT, (int(self.x), int(self.y)), int(size - 3))

    def collides_with(self, rect):
        return pygame.Rect(self.x - 10, self.y - 10, 20, 20).colliderect(rect)

class Pipe:
    def __init__(self):
        self.x = 400
        self.top_height = random.randint(100, 300)
        self.bottom_y = self.top_height + PIPE_GAP
        self.passed = False
        self.coin = Coin(self.x + PIPE_WIDTH // 2, self.top_height + PIPE_GAP // 2)

    def update(self):
        self.x -= PIPE_SPEED
        self.coin.x = self.x + PIPE_WIDTH // 2
        self.coin.update()

    def collides_with(self, rect):
        top_pipe = pygame.Rect(self.x, 0, PIPE_WIDTH, self.top_height)
        bottom_pipe = pygame.Rect(self.x, self.bottom_y, PIPE_WIDTH, 600 - self.bottom_y)
        return top_pipe.colliderect(rect) or bottom_pipe.colliderect(rect)

    def draw_cap(self, x, y, flipped=False):
        cap_rect = pygame.Rect(x - 10, y - (PIPE_CAP_HEIGHT if not flipped else 0), PIPE_WIDTH + 20, PIPE_CAP_HEIGHT)
        pygame.draw.rect(screen, PIPE_DARK, cap_rect)
        pygame.draw.rect(screen, PIPE_HIGHLIGHT, (cap_rect.x + 5, cap_rect.y, 6, PIPE_CAP_HEIGHT))

    def draw(self):
        pygame.draw.rect(screen, PIPE_GREEN, (self.x, 0, PIPE_WIDTH, self.top_height))
        pygame.draw.rect(screen, PIPE_LIGHT, (self.x + 5, 0, PIPE_WIDTH, self.top_height - 5))
        self.draw_cap(self.x, self.top_height, flipped=True)
        pygame.draw.rect(screen, PIPE_GREEN, (self.x, self.bottom_y, PIPE_WIDTH, 600 - self.bottom_y))
        pygame.draw.rect(screen, PIPE_LIGHT, (self.x + 5, self.bottom_y, PIPE_WIDTH, 600 - self.bottom_y - 5))
        self.draw_cap(self.x, self.bottom_y)

class Tree:
    def __init__(self):
        self.x = random.randint(0, 400)
        self.trunk_height = random.randint(30, 50)
        self.radius = random.randint(18, 25)
        self.speed = random.uniform(0.5, 1.5)

    def update(self):
        self.x -= self.speed
        if self.x + self.radius * 2 < 0:
            self.x = 400 + random.randint(0, 100)
            self.trunk_height = random.randint(30, 50)
            self.radius = random.randint(18, 25)

    def draw(self):
        base_y = 500
        pygame.draw.rect(screen, TREE_TRUNK, (self.x + 10, base_y - self.trunk_height, 10, self.trunk_height))
        pygame.draw.circle(screen, TREE_LEAF, (self.x + 15, base_y - self.trunk_height), self.radius)

class Base:
    def __init__(self):
        self.y = 500
        self.height = 100

    def draw(self):
        pygame.draw.rect(screen, GROUND, (0, self.y, 400, self.height))

class Cloud:
    def __init__(self):
        self.x = random.randint(0, 400)
        self.y = random.randint(20, 120)
        self.speed = random.uniform(0.2, 0.5)
        self.size = random.randint(40, 80)

    def update(self):
        self.x -= self.speed
        if self.x + self.size < 0:
            self.x = 400
            self.y = random.randint(20, 120)

    def draw(self):
        pygame.draw.ellipse(screen, WHITE, (self.x, self.y, self.size, self.size // 2))
        pygame.draw.ellipse(screen, (200, 200, 200), (self.x + 10, self.y + 5, self.size, self.size // 3))

def main():
    global chosen_skin
    global selected_skin
    global bird
    bird = Bird(chosen_skin)
    pipes = []
    trees = [Tree() for _ in range(6)]
    clouds = [Cloud() for _ in range(3)]
    base = Base()
    score = 0
    coins_collected = 0
    frame = 0

    while True:
        clock.tick(FPS)
        screen.fill(SKY)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    bird.flap()
                if event.key == pygame.K_ESCAPE:
                    pause_menu()

        bird.update()
        frame += 1

        if frame % 90 == 0:
            pipes.append(Pipe())

        for pipe in pipes:
            pipe.update()
            if not pipe.passed and pipe.x + PIPE_WIDTH < bird.x:
                pipe.passed = True
                score += 1
            if pipe.coin.collides_with(bird.get_rect()) and not pipe.coin.collected:
                pipe.coin.collected = True
                coins_collected += 1

        pipes = [p for p in pipes if p.x + PIPE_WIDTH > 0]

        for cloud in clouds:
            cloud.update()
        for tree in trees:
            tree.update()

        if bird.y > 600 - 100 or bird.y < 0:
            game_over_screen(score, coins_collected)
            return 'gameover'

        for pipe in pipes:
            if pipe.collides_with(bird.get_rect()):
                game_over_screen(score, coins_collected)
                return 'gameover'

        for cloud in clouds:
            cloud.draw()
        for tree in trees:
            tree.draw()
        for pipe in pipes:
            pipe.draw()
            pipe.coin.draw()

        base.draw()
        bird.draw()

        score_text = font.render(str(score), True, WHITE)
        screen.blit(score_text, (screen.get_width() // 2 - score_text.get_width() // 2, 50))

        coin_text = small_font.render(f"Coins: {coins_collected}", True, GOLD)
        screen.blit(coin_text, (10, 10))

        pygame.display.update()






def skin_menu():
    global selected_skin
    global chosen_skin
    while True:
        screen.fill(SKY)
        title = font.render("Select Your Skin", True, WHITE)
        screen.blit(title, (screen.get_width() // 2 - title.get_width() // 2, 100))

        skin_rects = []
        for i, skin in enumerate(available_skins):
            label = f"{skin.capitalize()}"
            color = RED if skin == "red" else BLUE if skin == "blue" else (160, 32, 240) if skin == "wizard" else (255, 100, 100)
            label_surf = small_font.render(label, True, color)
            x = screen.get_width() // 2 - label_surf.get_width() // 2
            y = 200 + i * 50
            label_rect = pygame.Rect(x - 10, y - 5, label_surf.get_width() + 20, label_surf.get_height() + 10)
            skin_rects.append((label_rect, skin))
            screen.blit(label_surf, (x, y))
            if i == selected_skin:
                pygame.draw.rect(screen, GOLD, label_rect, 2)

        start_text = small_font.render("Start", True, WHITE)
        start_rect = start_text.get_rect(center=(screen.get_width() // 2, 400))
        pygame.draw.rect(screen, SHADOW, start_rect.inflate(20, 10))
        screen.blit(start_text, start_rect)

        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for idx, (rect, skin) in enumerate(skin_rects):
                    if rect.collidepoint(event.pos):
                        selected_skin = idx
                        chosen_skin = skin  # Equip on selection
                if start_rect.collidepoint(event.pos):
                    return

def show_main_menu():
    while True:
        screen.fill(SKY)

        # Title
        title_text = font.render("Flappy Bird", True, WHITE)
        start_text = small_font.render("Play", True, WHITE)
        skin_text = small_font.render("Skins", True, WHITE)
        quit_text = small_font.render("Quit", True, WHITE)

        title_rect = title_text.get_rect(center=(screen.get_width() // 2, 150))
        start_rect = start_text.get_rect(center=(screen.get_width() // 2, 250))
        skin_rect = skin_text.get_rect(center=(screen.get_width() // 2, 300))
        quit_rect = quit_text.get_rect(center=(screen.get_width() // 2, 350))

        screen.blit(title_text, title_rect)
        pygame.draw.rect(screen, SHADOW, start_rect.inflate(20, 10))
        pygame.draw.rect(screen, SHADOW, skin_rect.inflate(20, 10))
        pygame.draw.rect(screen, SHADOW, quit_rect.inflate(20, 10))
        screen.blit(start_text, start_rect)
        screen.blit(skin_text, skin_rect)
        screen.blit(quit_text, quit_rect)

        pygame.display.update()
        clock.tick(30)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if start_rect.collidepoint(event.pos):
                    return "play"
                elif skin_rect.collidepoint(event.pos):
                    return "skins"
                elif quit_rect.collidepoint(event.pos):
                    return "quit"


if __name__ == "__main__":
    while True:
        choice = show_main_menu()
        if choice == "play":
            result = main()
            if result == "gameover":
                continue
        elif choice == "skins":
            skin_menu()
        elif choice == "credits":
            show_credits()
        elif choice == "quit":
            pygame.quit()
            sys.exit()
